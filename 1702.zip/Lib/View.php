<?php
namespace Lib;

class View
{
    static $var = array();
    static $view_path = '';
    static $cache_path = '';
    static $cache_path_mtime = '';
    static $view_name = '';

    static public function display($view_name)
    {
        self::$view_name = $view_name;
        self::$view_path = PATH.'/Views/'.$view_name;
        self::$cache_path = PATH.'/Cache/Views/'.$view_name;
        self::$cache_path_mtime = self::$cache_path.'.mtime';

        if (!is_file(self::$cache_path)) {
            self::processView();
        } else {
            $content = (int)file_get_contents(self::$cache_path_mtime);
            if (filemtime(self::$view_path) !== $content) {
                self::processView();
            }
        }

        include self::$cache_path;
    }

    static public function assign($var)
    {
        self::$var = $var;
    }

    static public function processView()
    {
        p('修改了');
        $cache_content = file_get_contents(self::$view_path);
        $view_var = pregMiddle($cache_content, '{-', '-}');
        for ($i=0; $i < count($view_var); $i++) { 
            $cache_content = str_replace(
                '{-'.$view_var[$i].'-}',
                '<?php echo self::$var['."'".$view_var[$i]."'".'] ?>',
                $cache_content
            );
        }


        file_put_contents(self::$cache_path_mtime, filemtime(self::$view_path));
        file_put_contents(self::$cache_path, $cache_content);
    }
}
