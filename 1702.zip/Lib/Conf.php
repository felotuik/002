<?php
namespace Lib;

class Conf
{
    static $confArr = array();
    static public function get($name)
    {
        if (isset(self::$confArr[$name])) {
            return self::$confArr[$name];
        } else {
            self::$confArr = include PATH.'/common/config.php';
            return self::$confArr[$name];
        }
    }
}
