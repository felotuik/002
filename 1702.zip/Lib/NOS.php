<?php
/*
*   网易蜂巢NOS类封装
*   作者：Yetmex
*   QQ: 664482903
*/

    namespace Lib;
    use NOS\NosClient;
    use NOS\Core\NosException;

class NOS
{
    static $nos = null;
    static public function newNOS()
    {
        if (self::$nos == null) {
            include 'webnet-nos/autoload.php';
            $accessKeyId = '4346cb0a740a42e1b053c9db98d765a8';
            $accessKeySecret = '1a6c1b9dca0f4268ad2355e70c43dc3f';
            $endPoint = 'nos-eastchina1.126.net';
            self::$nos = new NosClient($accessKeyId, $accessKeySecret, $endPoint);
        }

    }

    //新建桶
    static public function putBucket($bucket)
    {
        self::newNOS();
        try{
            return self::$nos->createBucket($bucket) == null ? true : false;
        } catch (NosException $e) {
            return false;
        }
    }

    //删除桶
    static public function delBucket($bucket)
    {
        self::newNOS();
        try{
            return self::$nos->deleteBucket($bucket) == null ? true : false;
        } catch (NosException $e) {
            return false;
        }
    }


    //上传数据到桶中的对象
    static public function uploadData($bucket, $object, $content)
    {
        self::newNOS();
        // 上传时对象不存在也会返回true，因为它会自动新建那个对象并写入数据
        // 如果对象已存在则覆盖
        try{
            return self::$nos->putObject($bucket, $object, $content) == null ? true : false;
        } catch (NosException $e) {
            return false;
        }
    }


    //文件下载
    static public function dlFile($bucket, $object = '')
    {
        self::newNOS();
        try{
            return self::$nos->getObject($bucket, $object);
        } catch (NosException $e) {
            return false;
        }
    }


    //文件删除
    static public function delFile($bucket, $object = '')
    {
        self::newNOS();
        try{
            if (is_array($object)) {
                return self::$nos->deleteObjects($bucket, $object) == null ? true : false;
            } else {
                return self::$nos->deleteObject($bucket, $object) == null ? true : false;
            }
            
        } catch (NosException $e) {
            return false;
        }
    }


    //判断文件是否存在
    static public function isFile($bucket, $object = '')
    {
        self::newNOS();
        try{
            return self::$nos->doesObjectExist($bucket, $object);
        } catch (NosException $e) {
            return false;
        }
    }


    //文件上传
    static public function uploadFile($bucket, $object = '', $path = '')
    {
        self::newNOS();
        try{
            return self::$nos->uploadFile($bucket, $object, $path) == null ? true : false;
        } catch (NosException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return false;
        }
    }


    //拷贝文件
    static public function copyFile($from_bucket = '', $from_object = '', $to_bucket = '', $to_object = '')
    {
        self::newNOS();
        try{
            return self::$nos->copyObject($from_bucket, $from_object, $to_bucket, $to_object) == null ? true : false;
        } catch (NosException $e) {
            return false;
        }
    }


    //生成文件限时访问url
    static public function signURL($bucket, $object, $timeout = 3600)
    {
        self::newNOS();
        try{
            $signUrl = self::$nos->signUrl($bucket, $object, $timeout);
            //return时不能直接echo，否则会出错
            return $signUrl;
        } catch (NosException $e) {
            return false;
        }
    }
}
