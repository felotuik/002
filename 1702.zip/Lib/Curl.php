<?php
namespace Lib;


class Curl
{
    static public function get($data, $getResultHeaders = false)
    {
        $ch = curl_init($data['url']);
        if (isset($data['post'])) {
            curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_POSTFIELDS, $data['post']);
        }
        if (isset($data['referer'])) {
            curl_setopt($ch, CURLOPT_REFERER, $data['referer']);
        }
        if (isset($data['cookie'])) {
            curl_setopt($ch, CURLOPT_COOKIE, $data['cookie']);
        }
        if (isset($data['header'])) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $data['header']);
        }
        if (!isset($data['timeout'])) $data['timeout'] = 45;

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, $data['timeout']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_HEADER, $getResultHeaders);
        curl_setopt($ch, CURLOPT_NOBODY, false);
        $res = curl_exec($ch);
        //网络出错时应对策略
        if ($res == '') {
            return false;
        }
        if ($getResultHeaders) {
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE)-4;
            $res_data['content'] = substr($res, $headerSize);
            $res_data['header'] = explode("\n", substr($res, 0, $headerSize));
            $resHeaderCount = count($res_data['header']);
            for ($i=0; $i < $resHeaderCount; $i++) {
                switch ($i) {
                    case 0:
                        $info = explode(' ', $res_data['header'][0]);
                        $info[0] = explode('/', $info[0]);
                        $res_data['header']['Scheme'] = $info[0][0];
                        $res_data['header']['Scheme-Ver'] = $info[0][1];
                        $res_data['header']['Status'] = $info[1];
                        $res_data['header']['Status-Info'] = $info[2];
                        break;
                    default:
                        $info = explode(': ', $res_data['header'][$i]);
                        $res_data['header'][$info[0]] = $info[1];
                        break;
                }
                unset($res_data['header'][$i]);
            }
        } else {
            $res_data = $res;
        }
        curl_close($ch);
        return $res_data;
    }

    static public function multi($data, $getResultHeaders = false)
    {
        $mh = curl_multi_init();

        foreach ($data as $k => $v) {
            $ch[$k] = curl_init($v['url']);
            if (isset($v['post'])) {
                curl_setopt($ch[$k], CURLOPT_POST, 1);
                curl_setopt($ch[$k], CURLOPT_POSTFIELDS, $v['post']);
            }
            if (isset($v['referer'])) {
                curl_setopt($ch[$k], CURLOPT_REFERER, $v['referer']);
            }
            if (isset($v['cookie'])) {
                curl_setopt($ch[$k], CURLOPT_COOKIE, $v['cookie']);
            }
            if (isset($v['header'])) {
                curl_setopt($ch[$k], CURLOPT_HTTPHEADER, $v['header']);
            }
            if (!isset($v['timeout'])) $v['timeout'] = 45;

            curl_setopt($ch[$k], CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch[$k], CURLOPT_HEADER, 0);
            curl_setopt($ch[$k], CURLOPT_TIMEOUT, $v['timeout']);
            curl_setopt($ch[$k], CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch[$k], CURLOPT_SSL_VERIFYPEER, 0);
            //获得响应头
            curl_setopt($ch[$k], CURLOPT_HEADER, $getResultHeaders);
            curl_setopt($ch[$k], CURLOPT_NOBODY, false);
            curl_multi_add_handle ($mh, $ch[$k]);
        }

        $active = null;
        do {
            $mrc = curl_multi_exec($mh, $active);
        } while ($mrc == CURLM_CALL_MULTI_PERFORM);

        while ($active && $mrc == CURLM_OK){
            do {
                $mrc = curl_multi_exec($mh, $active);
            } while ($mrc == CURLM_CALL_MULTI_PERFORM);
        }

        $res = array();
        foreach ($data as $k => $v) {
            curl_error($ch[$k]);
            if ($getResultHeaders) {
                //获得响应内容，包括头内容
                $res[$k]['content'] = curl_multi_getcontent($ch[$k]);
                //网络出错时应对策略
                if ($res[$k]['content'] == '') {
                    return false;
                }
                //获得响应结果里的：头大小
                $headerSize = curl_getinfo($ch[$k], CURLINFO_HEADER_SIZE)-4;
                //根据头大小去获取头信息内容并转为数组
                $res[$k]['header'] = explode("\n", substr($res[$k]['content'], 0, $headerSize));

                $resHeaderCount = count($res[$k]['header']);

                for ($i=0; $i < $resHeaderCount; $i++) {
                    switch ($i) {
                        case 0:
                            $info = explode(' ', $res[$k]['header'][0]);
                            $info[0] = explode('/', $info[0]);
                            $res[$k]['header']['Scheme'] = $info[0][0];
                            $res[$k]['header']['Scheme-Ver'] = $info[0][1];
                            $res[$k]['header']['Status'] = $info[1];
                            $res[$k]['header']['Status-Info'] = $info[2];
                            break;
                        default:
                            $info = explode(': ', $res[$k]['header'][$i]);
                            $res[$k]['header'][$info[0]] = $info[1];
                            break;
                    }
                    unset($res[$k]['header'][$i]);
                }
                $res[$k]['content'] = substr($res[$k]['content'], $headerSize);
            } else {
                $res[$k] = curl_multi_getcontent($ch[$k]);
            }
            curl_close($ch[$k]);
            curl_multi_remove_handle($mh, $ch[$k]);
        }
        curl_multi_close($mh);
        return $res;
    }
}
