<?php
namespace Lib;
use Lib\Conf;

class Mail
{
    static $smtp = null;
    static public function smtp($to, $title = '', $content = '', $add = array(), $attachment = array())
    {
        if (self::$smtp == null) {
            include PATH.'/Lib/PHPMailer/PHPMailerAutoload.php';
            self::$smtp = new \PHPMailer;
            //self::$smtp->SMTPDebug = 3; //启用详细调试输出
            self::$smtp->isSMTP(); //设置邮件包使用SMTP
            self::$smtp->Host = Conf::get('SMTP')['host']; //SMTP服务器
            self::$smtp->SMTPAuth = true; // 启用SMTP认证
            self::$smtp->Username = Conf::get('SMTP')['userName']; //SMTP用户名
            self::$smtp->Password = Conf::get('SMTP')['password']; //SMTP密码
            self::$smtp->SMTPSecure = Conf::get('SMTP')['secure']; //启用TLS加密，也可以使用SSL
            self::$smtp->Port = Conf::get('SMTP')['port']; //连接到的TCP端口
            self::$smtp->CharSet = Conf::get('SMTP')['charset'];
            self::$smtp->setFrom(Conf::get('SMTP')['fromMail'], Conf::get('SMTP')['fromName']); //发件人
            echo "<br>PHPMailer类实例化和相关设置准备完成";
        }

        self::$smtp->ClearAllRecipients(); //清除所有收件人，包括cc和bcc

        //如果使用数组则可以判断此邮件要发给多人
        if (is_array($to)) {
            for ($i=0; $i < count($to); $i++) { 
                self::$smtp->addAddress($to[$i]);
            }
        } else {
            self::$smtp->addAddress($to);
        }

        //附加信息
        if ($add) {
            if (isset($add['cc'])) {
                self::$smtp->addCC($add['cc']); //添加抄送
            }
            if (isset($add['bcc'])) {
                self::$smtp->addBCC($add['bcc']); //添加密送
            }
        }

        //支持多附件
        if ($attachment) {
            foreach ($attachment as $key => $value) {
                self::$smtp->addAttachment($value, $key);
            }
        }

        self::$smtp->isHTML(true); //设置格式为HTML
        self::$smtp->Subject = $title;
        self::$smtp->Body    = $content;
        self::$smtp->AltBody = $content; //邮件客户端不支持HTML的备用显示

        return self::$smtp->send();
    }
}

?>