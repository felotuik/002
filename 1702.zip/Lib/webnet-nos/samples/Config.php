<?php

class Config
{
    const NOS_ACCESS_ID = '4346cb0a740a42e1b053c9db98d765a8';
    const NOS_ACCESS_KEY = '1a6c1b9dca0f4268ad2355e70c43dc3f';
    const NOS_ENDPOINT = 'nos-eastchina1.126.net';
    const NOS_TEST_BUCKET = '';
}

