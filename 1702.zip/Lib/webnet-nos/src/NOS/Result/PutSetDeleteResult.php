<?php

namespace NOS\Result;


/**
 * Class PutSetDeleteResult
 * @package NOS\Result
 */
class PutSetDeleteResult extends Result
{
    /**
     * @return null
     */
    protected function parseDataFromResponse()
    {
        return null;
    }
}