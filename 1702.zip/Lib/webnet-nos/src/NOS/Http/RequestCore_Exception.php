<?php

namespace NOS\Http;

class RequestCore_Exception extends \Exception
{

}