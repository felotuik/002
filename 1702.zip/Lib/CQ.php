<?php
namespace Lib;


 /**
  * CQ数据引擎（Convenient and Quick）
  * 方便而快速的文件数据引擎
  * 实例：读取一个数量为1000的json数组再转换到PHP数组，该过程仅耗时0.0009微秒
  */

class CQ
{
    
    static $table = array();

    /**
     * 读取一张表的数据
     * @param  string $tableName
     * @param  string $object
     * @return bool
     */
    static public function get($tableName, $object)
    {
        if (self::readTable($tableName)) {
            if (isset(self::$table[$tableName][$object])) {
                return self::$table[$tableName][$object];
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    /**
     * 在表中新增一个项目
     * @param  string $tableName
     * @param  string $object
     * @param  string $content
     * @return bool
     */
    static public function insert($tableName, $object, $content)
    {
        if (self::readTable($tableName)) {
            $path = PATH.'/CQData/'.$tableName.'.json';
            self::$table[$tableName][$object] = $content;
            if (file_put_contents($path, json_encode(self::$table[$tableName]))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    /**
     * 更新一张表的数据
     * @param  string $tableName
     * @param  string $object
     * @param  string $content
     * @return bool
     */
    static public function set($tableName, $object, $content)
    {
        if (self::readTable($tableName)) {
            // 确定指定对象是否存在
            if (isset(self::$table[$tableName][$object])) {
                $path = PATH.'/CQData/'.$tableName.'.json';
                self::$table[$tableName][$object] = $content;
                if (file_put_contents($path, json_encode(self::$table[$tableName]))) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    /**
     * 判断指定表是否存在
     * @param  string $tableName
     * @return bool false|string $path
     */
    static public function isTable($tableName)
    {
        $path = PATH.'/CQData/'.$tableName.'.json';
        if (is_file($path)) {
            return $path;
        } else {
            return false;
        }
    }


    /**
     * 载入一张表到内存中
     * @param  string $tableName
     * @return bool
     */
    static public function readTable($tableName)
    {
        $path = self::isTable($tableName);
        if ($path) {
            self::$table[$tableName] = json_decode(file_get_contents($path), true);
            return true;
        } else {
            return false;
        }
    }
}
