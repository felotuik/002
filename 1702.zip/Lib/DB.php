<?php
//全局模块

namespace Lib;
use Lib\Conf;

class DB
{
    static $m = null;

    //实例化medooo类
    static public function newMedoo()
    {
        if (self::$m == null) {
            include PATH.'/Lib/Medoo.php';
            self::$m = new \Lib\Medoo([
                'database_type' => 'mysql',
                'database_name' => Conf::get('DB')['dbName'],
                'server' => Conf::get('DB')['host'],
                'username' => Conf::get('DB')['userName'],
                'password' => Conf::get('DB')['password'],
                'charset' => 'utf8',
            ]);
        }
    }

    //查询
    static public function select($table, $columns, $where)
    {
        self::newMedoo();
        return self::$m->select($table, $columns, $where);
    }

    //插入
    static public function insert($table, $data)
    {
        self::newMedoo();
        return self::$m->insert($table, $data);
    }

    //更新
    static public function update($table, $data, $where)
    {
        self::newMedoo();
        return self::$m->update($table, $data, $where);
    }

    //删除
    static public function delete($table, $where)
    {
        self::newMedoo();
        return self::$m->delete($table, $where);
    }

    //替换
    static public function replace($table, $column, $search, $replace, $where)
    {
        self::newMedoo();
        return self::$m->replace($table, $column, $search, $replace, $where);
    }

    //获取一条数据
    static public function get($table, $columns, $where)
    {
        self::newMedoo();
        return self::$m->get($table, $columns, $where);
    }

    //判断指定条件是否符合
    static public function has($table, $where)
    {
        self::newMedoo();
        return self::$m->has($table, $where);
    }

    //取得列的最大值
    static public function max($table, $column, $where)
    {
        self::newMedoo();
        return self::$m->max($table, $column, $where);
    }

    //取得列的最小值
    static public function min($table, $column, $where)
    {
        self::newMedoo();
        return self::$m->min($table, $column, $where);
    }

    //取得列的平均值
    static public function avg($table, $column, $where)
    {
        self::newMedoo();
        return self::$m->avg($table, $column, $where);
    }

    //某个列字段相加
    static public function sum($table, $column, $where)
    {
        self::newMedoo();
        return self::$m->sum($table, $column, $where);
    }
}
