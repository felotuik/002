<?php
namespace Lib;

class Route
{
    static $uri = null; //用户请求的网址
    static $is_finish = false; //是否完成路由匹配

    //所有路由方法
    static public function any($pre_route, $act = null)
    {
        if (self::index()) return true;
        self::load($pre_route, $act);
    }

    //路由方法：GET
    static public function get($pre_route, $act = null)
    {
        if (self::index()) return true;
        if ($_SERVER['REQUEST_METHOD'] == 'GET') {
            self::load($pre_route, $act);
        }
    }

    //路由方法：POST
    static public function post($pre_route, $act = null)
    {
        if (self::index()) return true;
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            self::load($pre_route, $act);
        }
    }

    //路由方法：PUT
    static public function put($pre_route, $act = null)
    {
        if (self::index()) return true;
        if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
            self::load($pre_route, $act);
        }
    }

    //路由方法：DELETE
    static public function delete($pre_route, $act = null)
    {
        if (self::index()) return true;
        if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
            self::load($pre_route, $act);
        }
    }

    //加载处理路由
    static public function load($rou, $act)
    {
        $param = array();
        $rou = explode('/', $rou);
        if (count(self::$uri) == count($rou)) {
            $g_count = count($rou);
            for ($i=0; $i < $g_count; $i++) {
                if ($rou[$i] == self::$uri[$i]) {
                    unset($rou[$i]);
                } elseif (substr($rou[$i], 0, 1) == '$') {
                    $param[substr($rou[$i], 1)] = self::$uri[$i];
                    unset($rou[$i]);
                }
            }
        }
        if (count($rou) == 0) {
            self::$is_finish = true;
            if (is_string($act)) {
                $act = explode('@', $act);
                $act_app = 'App\\'.$act[0];
                $act_app = new $act_app;
                $act_app->$act[1]($param);
            } else {
                $act($param);
            }
        }
    }

    //基本处理：判断匹配状态、获取URI等
    static public function index()
    {
        if (self::$is_finish) {
            return true;
        }
        if (self::$uri == null) {
            self::$uri = explode('?', trim($_SERVER['REQUEST_URI'], '/'))[0];
            self::$uri = explode('/', self::$uri);
        }
    }

    static public function end()
    {
        if (!self::$is_finish) {
            header('HTTP/1.1 404 Not Found');
            header('status: 404 Not Found');
            include 'Views/404.html';
        }
        return false;
    }
}
