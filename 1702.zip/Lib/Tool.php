<?php
namespace Lib;
use Lib\Curl;


class Tool
{
    public function cesu()
    {
        $startTime = microtime(true);
        $a = 'http://dlsw.baidu.com/sw-search-sp/soft/1a/30708/TankHero_4399_Ver1.0.0.0.1406601180.exe';
        if (isset($_GET['url'])) {
            $a = $_GET['url'];
        }
        $a = Curl::get([
            'url' => $a,
        ]);
        $time = round((microtime(true)*100000-$startTime*100000)/100000, 2);

        file_put_contents('cesu.cache', $a);
        $size = filesize('cesu.cache');
        unlink('cesu.cache');
        $speed = $size / $time;

        echo '<br>文件大小：'.formatSize($size);
        echo '<br>网速：'.formatSize($speed).'/s';
        
    }

    public function query()
    {
        $f = new QL;
        //获取采集对象
        $hj = $f::Query('http://bbs.hyyyp.com/t/106.html',array(
                'title'=>array('h1', 'title'),
        ));
    }
}

?>