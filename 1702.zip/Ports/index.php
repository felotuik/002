<?php
namespace ports;
use Lib\Mail;
use Lib\CQ;

class index
{
    public function __construct()
    {
        //示例接口
    }
}

?>