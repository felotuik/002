<?php
namespace Ports;
use Lib\Curl;
use Lib\NOS;

class wall
{
    public function __construct()
    {
        ignore_user_abort(true);
        set_time_limit(0);
        for ($i=0; $i < 800; $i++) {
            if ($i+1 == 1) {
                $url = 'http://desktoppapers.co';
            } else {
                $url = 'http://desktoppapers.co/page/'.($i+1).'/';
            }
            $page_get[$i] = array(
                'url' => $url
            );
        }

        $url_data = array();
        for ($i=0; $i < 80; $i++) { //80
            $arr = array();
            for ($i2=($i*10); $i2 < ($i*10+10); $i2++) { 
                $arr[] = $page_get[$i2];
            }
            $data = Curl::multi($arr);
            for ($i3=0; $i3 < 10; $i3++) {
                $now = explode(' <ul class="postul"> ', $data[$i3])[1];
                $now = explode('</ul></div></div><div class="content"> ', $now)[0];
                $now = explode('<li class="postli">', $now);
                for ($i4=1; $i4 < 13; $i4++) {
                    $url_data[] = explode('" title="', explode(' <a href="', $now[$i4])[1])[0];
                }
            }
            if (is_dir(PATH.'/ex')) {
                exit();
            }
            sleep(10);
        }

        for ($i=0; $i < 9600; $i++) {
            $pid = randStr();
            $name = explode('/', $url_data[$i])[3];
            $url = "http://papers.co/wallpaper/papers.co-$name-25-wallpaper.jpg";
            $dl = Curl::get(array(
                'url' => $url
            ));
            NOS::uploadData('photos', "wallpaper/$pid.jpg", $dl);
            $all[$i] => array(
                'name' => $name,
                'pid' => $pid,
                'time' => time()
            );
            if (is_dir(PATH.'/ex')) {
                exit();
            }
            sleep(10);
        }
        file_put_contents(PATH.'/all.json', json_encode($all));
        exit();
    }
}










?>