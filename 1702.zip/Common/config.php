<?php
//设置信息

return array(
    'DB' => array(
        'host' => 'localhost',
        'userName' => 'admin',
        'password' => '123456',
        'dbName' => 'ealog'
    ),

    'SMTP' => array(
        'host' => 'smtp.qq.com',
        'userName' => '664482903@qq.com',
        'password' => 'cbfxqympgqkybefj',
        'secure' => 'tls',
        'port' => 587,
        'charset' => 'UTF-8',
        'fromMail' => '664482903@qq.com',
        'fromName' => 'LB云服务',
    ),















);








?>