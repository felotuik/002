<?php

//打印调试函数
function p($content = '')
{
    $style = 'color: #222;font-family:consolas;font-size:16px;padding:10px 14px;background:#ECF4FD;border:1px solid #A7C9F6;overflow:hidden;margin-bottom:8px;box-shadow:1px 1px 3px #bbb;';
    echo '<style>.box,pre{'.$style.'}</style>';
    $type = gettype($content);
    switch ($type) {
        case 'string':
            $right = '<div style="float:right"><b>'.$type.' | 行：'.__LINE__.'</b></div>';
            echo '<div class="box">'.$content.$right.'</div>';
            break;
        default:
            var_dump($content);
            break;
    }


}


//自动加载类
function autoLoadClass($class)
{
    $libPath = PATH.'/'.str_replace('\\', '/', $class).'.php';
    if (is_file($libPath)) {
        include $libPath;
    }
}



//GET方法封装
function get($name, $fitt = '')
{
    if (isset($_GET[$name])) {
        if ($fitt !== '') {
            switch ($fitt) {
                case 'int':
                    return is_numeric($_GET[$name]) ? $_GET[$name] : false;
                    break;
                default:
                    return false;
                    break;
            }
        } else {
            return $_GET[$name];
        }
    } else {
        return false;
    }
}



//POST方法封装
function post($name, $fitt = '')
{
    if (isset($_POST[$name])) {
        if ($fitt !== '') {
            switch ($fitt) {
                case 'int':
                    return is_numeric($_POST[$name]) ? $_POST[$name] : false;
                    break;
                default:
                    return false;
                    break;
            }
        } else {
            return $_POST[$name];
        }
    } else {
        return false;
    }
}



//接口处理函数：返回JSON
function show($code = 0, $msg = '', $data = array()){
    if (!is_numeric($code)) {
        return false;
    }
    $result = array(
        'code' => $code,
        'msg' => urlencode($msg),
        'data' => $data
    );
    if ($data == array()) {
        unset($result['data']);
    }
    return urldecode(json_encode($result));
}



//大小格式化
function formatSize($b, $times = 0) {
    if ($b > 1024) {
        $temp = $b / 1024;
        return formatSize($temp, $times + 1);
    } else {
        $unit = 'B';
        switch ($times) {
            case '0' : $unit = 'B';
                break;
            case '1' : $unit = 'KB';
                break;
            case '2' : $unit = 'MB';
                break;
            case '3' : $unit = 'GB';
                break;
            case '4' : $unit = 'TB';
                break;
            case '5' : $unit = 'PB';
                break;
            case '6' : $unit = 'EB';
                break;
            case '7' : $unit = 'ZB';
                break;
            default : $unit = '单位未知';
        }
        return sprintf('%.2f', $b).$unit;
    }
}



//随机字符串生成
function randStr($group = '', $length = 10)
{
    if ($group == '') {
        return md5(microtime(true).randStr('en+EN+int+sym'));
    }
    $en = 'abcdefghijklmnopqrstuvwxyz';
    $EN = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $int = '0123456789';
    $sym = '~!@#%^&*()_+-={[:}]|';
    $sample = '';
    $group = explode('+', $group);
    foreach ($group as $key => $value) {
        $sample .= $$value;
    }
    $fin = '';
    $sample_length = strlen($sample);
    for ($i=0; $i < $length; $i++) { 
        $fin .= substr($sample, mt_rand(0, $sample_length), 1);
    }
    return $fin;
}



//日志
function newLog($content)
{
    $dir = PATH.'/Log/'.date('Y-m-d');
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    $file = $dir.'/'.date('H').'.txt';
    if (!is_file($file)) {
        file_put_contents($file, date('[H:i:s] ').$content.PHP_EOL);
    } else {
        file_put_contents($file, date('[H:i:s] ').$content.PHP_EOL, FILE_APPEND);
    }
}



//AES256加密解密
function AES256_encrypt($content = '', $key = 'Vbfv+Ft#AZp.RM-Vl=eA++CttzUbQ') {
    return openssl_encrypt($content, 'AES256', $key, false, substr(md5($key), 0, 16));
}
function AES256_decrypt($content = '', $key = 'Vbfv+Ft#AZp.RM-Vl=eA++CttzUbQ') {
    return openssl_decrypt($content, 'AES256', $key, false, substr(md5($key), 0, 16));
}



//匹配两字符串之间
function pregMiddle($str, $start, $end)
{
    $pattern = '/('.$start.').*?('.$end.')/is';
    preg_match_all($pattern, $str, $res);
    for ($i=0; $i < count($res[0]); $i++) { 
        $res[0][$i] = str_replace($start, '', $res[0][$i]);
        $res[0][$i] = str_replace($end, '', $res[0][$i]);
    }
    return $res[0];
}



//过滤非法字符
function filterStr($str)
{
    $sample = array(
        '<' => '&lt;',
        '>' => '&gt;',
        '&' => '&#x26;',
        '?' => '&#x3f;',
        ',' => '&#x2c;',
        "\$" => '&#x24;',
        "\'" => '&#x27;',
        "\"" => '&#x22;'
    );
    foreach ($sample as $k => $v) {
        $str = str_replace($k, $v, $str);
    }
    return $str;
}

?>