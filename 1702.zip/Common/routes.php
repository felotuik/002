<?php
use Lib\Route;

#以下是系统路由，请不要去除
#API接口路由
if (SET_apiServer) {
    Route::any('api/$app', function($p) {
        if (is_file('Ports/'.$p['app'].'.php')) {
            $a = 'Ports\\'.$p['app'];
            $a = new $a;
            if (method_exists($a, 'index')) {
                echo $a->index();
            } else {
                echo show(600, 'App does not exist');
            }
        } else {
            echo show(600, 'App does not exist');
        }
    });
    Route::any('api/$app/$method', function($p) {
        if (is_file('Ports/'.$p['app'].'.php')) {
            $a = 'Ports\\'.$p['app'];
            $a = new $a;
            if (method_exists($a, $p['method'])) {
                echo $a->$p['method']();
            } else {
                echo show(601, 'Method does not exist');
            }
        } else {
            echo show(600, 'App does not exist');
        }
    });
}
#结束处理路由
Route::end();
