<?php

    //全局常量
    define('PATH', dirname(__FILE__)); #框架目录
    define('LIB', PATH.'/Lib'); #类路径
    define('CACHE', PATH.'/Cache'); #缓存路径

    //环境配置
    ini_set('display_errors', 'On');
    ini_set('max_execution_time', '0');
    date_default_timezone_set('PRC');
    header('Content-type: text/html; charset=utf-8');

    //服务开关
    define('SET_webSwitch', true); #全站开关
    define('SET_apiServer', true); #接口服务器

    if (!SET_webSwitch) {
        exit('Please visit later....');
    }

    session_start();
    $start_time = microtime(true); #开始时间
    $start_memory = memory_get_usage(); #内存占用

    //其它
    include 'Common/function.php';
    spl_autoload_register('autoLoadClass');

    if ($_SERVER['REQUEST_URI'] == '/') {
        $index = new App\index;
        $index->index();
    } else {
        include 'Common/routes.php';
    }
