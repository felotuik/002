<?php
//首页控制器

namespace App;
use \Lib\DB;
use \Lib\View;

class index
{
    //构造方法：判断获取用户登陆状态和昵称
    public function __construct()
    {
    }

    //首页
    public function index()
    {
    }
}
